
CREATE TABLE craftsman(
    id SERIAL PRIMARY KEY ,
    name VARCHAR(30) NOT NULL CHECK (name ~ '^[a-zA-Z ]+$') ,
    email VARCHAR(50) UNIQUE CHECK (email ~* '^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$'),
    address VARCHAR(30) ,
    phone VARCHAR(10) CHECK (phone ~ '^\d{10}$')
);

CREATE TABLE category(
    id SERIAL PRIMARY KEY ,
    name VARCHAR(30) NOT NULL ,
    descriptions VARCHAR(200)
);

CREATE TABLE photo(
    id SERIAL PRIMARY KEY ,
    name VARCHAR(20) NOT NULL
);

CREATE TABLE product(
    id SERIAL PRIMARY KEY ,
    name VARCHAR(30) NOT NULL ,
    details VARCHAR(200),
    price DOUBLE PRECISION NOT NULL ,
    category_id INTEGER REFERENCES category,
    craftsman_id INTEGER REFERENCES craftsman
);

CREATE TABLE product_photo(
    product_id INTEGER REFERENCES product,
    photo_id INTEGER REFERENCES photo
);

CREATE TABLE product_stock(
    product_id INTEGER REFERENCES product,
    quantity INTEGER,
    date TIMESTAMP NOT NULL
);
CREATE TABLE currency(
    id SERIAL PRIMARY KEY ,
    name VARCHAR(20) NOT NULL ,
    ariary_value DOUBLE PRECISION NOT NULL ,
    date TIMESTAMP NOT NULL
);
CREATE TABLE country(
    id SERIAL PRIMARY KEY ,
    name VARCHAR(20) NOT NULL ,
    currency_id INTEGER REFERENCES currency
);

CREATE TABLE discount(
    product_id INTEGER REFERENCES product,
    value DOUBLE PRECISION DEFAULT 0 CHECK ( value <= 1 ),
    beginning_date TIMESTAMP NOT NULL ,
    end_date TIMESTAMP
);
CREATE TABLE customer(
    id SERIAL PRIMARY KEY ,
    name VARCHAR(50) NOT NULL CHECK (name ~ '^[a-zA-Z]+$') ,
    email VARCHAR(50) UNIQUE NOT NULL CHECK (email ~* '^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$'),
    password VARCHAR(20) NOT NULL ,
    phone VARCHAR(20) CHECK (phone ~ '^\d{10}$') ,
    date TIMESTAMP NOT NULL ,
    address VARCHAR(30),
    bank_card VARCHAR(30) NOT NULL ,
    country_id INTEGER REFERENCES country
);

CREATE TABLE product_order(
    id SERIAL PRIMARY KEY ,
    quantity INTEGER,
    product_id INTEGER REFERENCES product,
    customer_id INTEGER REFERENCES customer,
    order_date TIMESTAMP NOT NULL ,
    send_order_date TIMESTAMP
);

CREATE TABLE product_history(
    id SERIAL PRIMARY KEY ,
    product_id INTEGER REFERENCES product,
    craftsman_id INTEGER REFERENCES craftsman,
    customer_id INTEGER DEFAULT 0,
    quantity INTEGER,
    total_price DOUBLE PRECISION,
    purchase_date TIMESTAMP NOT NULL ,
    sale_date TIMESTAMP
);

/*VIEW  select customers with their product that they bought*/

CREATE or REPLACE VIEW customer_with_product AS
    SELECT  ph.customer_id, c.name customer_name, ph.craftsman_id, cr.name craftsman_name, ph.product_id, p.name product_name, quantity, total_price, sale_date FROM product_history ph
    JOIN customer c ON c.id = ph.customer_id
    JOIN product p ON p.id = ph.product_id
    JOIN craftsman cr ON cr.id = ph.craftsman_id
    ORDER BY sale_date DESC;


/*this function search a customer in histories*/
CREATE OR REPLACE FUNCTION search_customer_in_history(customer_id INTEGER) RETURNS TABLE (
        customer_id INTEGER,
        customer_name TEXT,
        craftsman_id INTEGER,
        craftsman_name TEXT,
        product_id INTEGER,
        product_name TEXT,
        quantity INTEGER,
        total_price DOUBLE PRECISION,
        sale_date TIMESTAMP )

    AS $$
    SELECT *FROM customer_with_product
    WHERE customer_id = $1;
    $$ LANGUAGE SQL;


INSERT INTO craftsman (name, email, address, phone)
VALUES
('John Smith', 'john.smith@example.com', '123 Main St', '5551234567'),
('Jane Doe', 'jane.doe@example.com', '456 Park Ave', '5559876543'),
('Bob Johnson', 'bob.johnson@example.com', '789 Broadway', '5555555555'),
('Samantha Lee', 'samantha.lee@example.com', '321 Elm St', '5551112222'),
('David Kim', 'david.kim@example.com', '567 Oak Ave', '5554443333');
